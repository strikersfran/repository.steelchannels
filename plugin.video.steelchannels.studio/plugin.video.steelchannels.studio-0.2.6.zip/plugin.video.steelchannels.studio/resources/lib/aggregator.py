# -*- coding: utf-8 -*-

import xbmcgui
from .addon import *
from resources.servers.cinecalidad import cinecalidad
from resources.servers.tvchannels import tvchannels
from resources.lib.database import create as create_database, get_movie_no_info, set_movie_info_art
from resources.lib.tmdb3 import set_key, set_cache, set_locale, Collection, Movie, Person, Studio
import json

PG = 0

def progress_update(dialog):
    def inner(current):
        dialog.update(current)

    return inner

def progress_info(dialog):
    def inner(current, total, start=False, end=False):
        global PG
        dialog.update(PG + current)
        if current + 1 == total and end is True:
            PG += total

    return inner


def get_dialog_header():
    return '%s - %s' % (ADDON_NAME, ADDON_VERSION)


def create_dialog(message):
    dialog = xbmcgui.DialogProgressBG()
    dialog.create(get_dialog_header(), message)
    return dialog


def aggregate(action):
    dialog = create_dialog(get_message(action))
    callback = progress_update(dialog)

    #para constuir la base de datos en caso de que no exista
    create_database()

    callback(5)
    tvchannels(action,callback)
    cinecalidad(action,callback)  

    tmdb_config()

    movies = get_movie_no_info()

    for movie in movies:        
        movieInfo, movieArt = tmdb_movie_info(movie[3])
        #guardamos la informacion en la base de dtos
        set_movie_info_art(movie[0],json.dumps(movieInfo),json.dumps(movieArt))

    dialog.close()
    #log("agregate")


def tmdb_config():
    set_key('e122a8356e1194b089089d7e49e09f62')
    set_cache(engine='file', filename='tmdb3cache')
    set_locale('es', 'es')

#para estraer la información del api TMDB
def tmdb_movie_info(id):
    m = Movie(id)
    geners = []
    countries = []
    studios = []
    casts = []
    poster = m.poster.geturl()

    for gener in m.genres:
        geners.append(gener.name)
    for country in m.countries:
        countries.append(country.name)
    for studio in m.studios:
        studios.append(studio.name)
    for cast in m.cast:
        casts.append(cast.name)

    movieInfo={
        'title':m.title,
        'originaltitle':m.originaltitle,
        'genre': geners,
        'country': countries,
        'year': "" if m.releasedate is None else m.releasedate.year,
        'plot': m.overview,
        'studio': studios,
        'mediatype': 'movie',
        'cast':casts
    }
    movieArt={
        'thumb': m.backdrop.geturl(), 
        'poster': poster,
        'icon': m.backdrop.geturl(), 
        'landscape':m.backdrop.geturl(),
        'clearart':m.backdrop.geturl(),
        'clearlogo':m.backdrop.geturl(),
        'fanart': m.backdrop.geturl()
    }

    return movieInfo, movieArt
