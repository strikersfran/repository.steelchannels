# -*- coding: utf-8 -*-
from bs4 import BeautifulSoup

def cinecalidad():
    base_url = "https://cinecalidad.ms/"