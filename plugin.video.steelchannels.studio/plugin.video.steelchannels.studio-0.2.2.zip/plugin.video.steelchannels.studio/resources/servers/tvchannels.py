import xbmcgui
import xbmcplugin
import requests
import json
from resources.lib.database import *
from resources.lib.loggers import *

channels_url = "https://raw.githubusercontent.com/strikersfran/repository.steelchannels/master/tvchannels.json"


def tvchannels(action,callback):
    try:
        response = requests.get(channels_url, timeout=30)
        channels = response.json()

        for channel in channels:
            channel["source"] = json.dumps(channel["source"])
            add_tv(channel)
        
        callback(50)

    except requests.exceptions.Timeout:
        debug("Tiempo exedido para acceder a la lista de canales")
        return False
    except requests.exceptions.RequestException as e:    
        debug("tvchannels Excepcion: " +str(e))
        return False

#funcion para reproducir una canal
def play(handle,sources):
    
    list = []
    index = 0 #seleccion por defecto

    if len(sources) > 1:
        for i in range(len(sources)):
            list.append("Opción "+str(i+1))

        index = xbmcgui.Dialog().contextmenu(list)
        xbmcplugin.setResolvedUrl(handle, True, listitem=create_list(sources[index]))

    else:
        xbmcplugin.setResolvedUrl(handle, True, listitem=create_list(sources[0]))
        
def create_list(file):      
    
    post = "|user-agent=ExoPlayer"
    list_item = xbmcgui.ListItem(path=file+post)        
    list_item.setInfo(type='video', infoLabels={'Title': "", 'plot': ""})
    
    if ".m3u8" in file:
        list_item.setProperty('inputstream', 'inputstream.adaptive')
        list_item.setProperty('inputstream.adaptive.manifest_type', "hls")  
        #list_item.setProperty('inputstream.adaptive.stream_headers', 'user-agent='+USERAGENT)            
        #list_item.setProperty('inputstream.adaptive.stream_selection_type', 'adaptive')       
        list_item.setContentLookup(False)
    else:
        list_item.setMimeType("video/mp4")

    return list_item
        

