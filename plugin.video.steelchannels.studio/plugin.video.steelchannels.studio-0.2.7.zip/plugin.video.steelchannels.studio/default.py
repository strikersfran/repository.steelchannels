# -*- coding: utf-8 -*-

import sys
from resources.lib.loggers import showInfoNotification
from resources.lib.loggers import showErrorNotification
from resources.lib.aggregator import aggregate,update_tv

try:    
    param = sys.argv[1]
    if param == "action=download":
        aggregate(30201)#descargar
    elif param == "action=download_tv":
        update_tv("download_tv")
    else:
        aggregate(30202)#actualizar

    showInfoNotification("Contenido Actualizado")
    #xbmc.executebuiltin('RestartApp')
except:
    showErrorNotification("Error al ejecutar la descarga")