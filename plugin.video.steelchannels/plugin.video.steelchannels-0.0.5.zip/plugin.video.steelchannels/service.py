# -*- coding: utf-8 -*-

import xbmc

from core.addon import SERVICE_FREQUENCY
from core.loggers import showInfoNotification
from default import run

MONITOR = xbmc.Monitor()

if __name__ == '__main__':
    while not MONITOR.abortRequested():        
        showInfoNotification('Ejecutando el servicio')
        run()
        if MONITOR.waitForAbort(SERVICE_FREQUENCY * 3600):
            break
