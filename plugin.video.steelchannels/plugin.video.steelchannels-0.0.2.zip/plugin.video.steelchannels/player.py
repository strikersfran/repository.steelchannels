# -*- coding: utf-8 -*-
import sys
from urllib.parse import urlencode, parse_qsl
import xbmcgui
import xbmcplugin
from core.loggers import log, showInfoNotification
from core.database import *
from providers.cinecalidad import play as cinecalidad_play
from providers.tvchannels import play as tvchannels_play
import json


class replacement_stderr(sys.stderr.__class__):
    def isatty(self): return False

sys.stderr.__class__ = replacement_stderr

# Get the plugin url in plugin:// notation.
__url__ = sys.argv[0]
# Get the plugin handle as an integer number.
__handle__ = int(sys.argv[1])

def get_url(**kwargs):
    """
    Create a URL for calling the plugin recursively from the given set of keyword arguments.

    :param kwargs: "argument=value" pairs
    :return: plugin call URL
    :rtype: str
    """
    return '{}?{}'.format(__url__, urlencode(kwargs))

def get_menu():
    MENU = {"TV","PELICULAS","SERIES"}

    return MENU

def show_menu():
    xbmcplugin.setPluginCategory(__handle__, 'Menú Principal')
    xbmcplugin.setContent(__handle__, 'files')

    menu = get_menu()

    for item in menu:
        list_item = xbmcgui.ListItem(label=item)

        url = get_url(action='listing', category=item)

        is_folder = True
        xbmcplugin.addDirectoryItem(__handle__, url, list_item, is_folder)

    xbmcplugin.addSortMethod(__handle__, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(__handle__)

def list_content(category):
    if category == "PELICULAS":
        movies = get_movie_all()
        list_movies(movies)
    elif category == "SERIES":
        log("OPCION DE SERIES SELEECIONADA")
        showInfoNotification("OPCION EN CONSTRUCCIÓN")
    elif category == "TV":
        tvs = get_tv_all()
        list_tvs(tvs)

#para listar todos los canales de tv
def list_tvs(tvs):
    xbmcplugin.setPluginCategory(__handle__, 'CANALES DE TV')
    xbmcplugin.setContent(__handle__, 'video')

    for tv in tvs:

        list_item = xbmcgui.ListItem(label=tv[1])

        #obtenemos las fuentes de los canales
        #sources = json.loads(tv[4])
        
        movieInfo={'title': tv[1],'genre': tv[3],'mediatype': 'movie'}        
        movieArt={'thumb': tv[2], 'icon': tv[2], 'fanart': tv[2]}

        list_item.setInfo('video',movieInfo)
        list_item.setArt(movieArt)
        list_item.setProperty('IsPlayable', 'true')
        # Example: plugin://plugin.video.example/?action=play&video=251
        url = get_url(action='play', video=tv[0], type="tv")
        is_folder = False
        xbmcplugin.addDirectoryItem(__handle__, url, list_item, is_folder)

    xbmcplugin.addSortMethod(__handle__, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(__handle__)

def list_movies(movies):    
    #log("Data data"+str(m.poster))

    xbmcplugin.setPluginCategory(__handle__, 'PELICULAS')
    xbmcplugin.setContent(__handle__, 'movies')

    #data = xbmc.executebuiltin('plugin://plugin.video.themoviedb.helper?info=fanart&amp;type=movie&amp;imdb_id=595871')
    #log("Data data"+str(data))

    for movie in movies:

        list_item = xbmcgui.ListItem(label=movie[4])

        #si una pelicula tiene valor en movie_info y movie_art
        #entonces extreamos su informacion
        if movie[5] and movie[6]:
            #convertimos el str a json list
            movieInfo = json.loads(movie[5])
            movieArt = json.loads(movie[6])
        else:
            movieInfo={'title': movie[4],'genre': movie[5],'mediatype': 'movie'}        
            movieArt={'thumb': movie[2], 'icon': movie[2], 'fanart': movie[2]}

        list_item.setInfo('video',movieInfo)
        list_item.setArt(movieArt)
        list_item.setProperty('IsPlayable', 'true')
        # Example: plugin://plugin.video.example/?action=play&video=251
        url = get_url(action='play', video=movie[0], type="movie")
        is_folder = False
        xbmcplugin.addDirectoryItem(__handle__, url, list_item, is_folder)

    xbmcplugin.addSortMethod(__handle__, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(__handle__)

#para ejecutar la pelicula
def play_movie(id):
    #buscamos en la base de datos el tipo de servidor
    movie_urls = get_movie(id)
    
    if movie_urls[0][1] == "cinecalidad":
        url = dict(parse_qsl("server=cinecalidad&ok=0&streamlare=0&fembed=0&trid="+str(id)+"&trtype=1"))
        for row in movie_urls:
            url[row[8]]=row[9]
        
        #urlResolver(__handle__,urlencode(url))
        cinecalidad_play(__handle__,urlencode(url))

#para ejecutar la serie
def play_serie(id):
    log("Play series en construcción")
    showInfoNotification("Play series en construcción")

#para ejecutar la tv
def play_tv(id):
    tv = get_tv(id)

    log(tv)

    sources = json.loads(tv[4])

    if len(sources) >0:
        tvchannels_play(__handle__,sources)
    else:
        showInfoNotification("Canala no encontrado")

def router(paramstring):
    """
    Router function that calls other functions
    depending on the provided paramstring

    :param paramstring: URL encoded plugin paramstring
    :type paramstring: str
    """
    # Parse a URL-encoded paramstring to the dictionary of
    # {<parameter>: <value>} elements
    params = dict(parse_qsl(paramstring))
    # Check the parameters passed to the plugin
    if params:
        if params['action'] == 'listing':
            # Display the list of videos in a provided category.
            list_content(params['category'])
            log("Action listing")
        elif params['action'] == 'play':
            # Play a video from a provided URL.
            log("Action Play")
            if params['type'] == 'movie':
                play_movie(params['video'])
            elif params['type'] == 'serie':
                play_serie(params['video'])
            elif params['type'] == 'tv':
                play_tv(params['video'])
            #urlResolver(__handle__,url)
            #play_video(params['video'])
        else:
            # If the provided paramstring does not contain a supported action
            # we raise an exception. This helps to catch coding errors,
            # e.g. typos in action names.
            raise ValueError('Invalid paramstring: {}!'.format(paramstring))
    else:
        # If the plugin is called from Kodi UI without any parameters,
        # display the list of video categories
        show_menu()


if __name__ == '__main__':
    # Call the router function and pass the plugin call parameters to it.
    # We use string slicing to trim the leading '?' from the plugin call paramstring
    router(sys.argv[2][1:])