# -*- coding: utf-8 -*-
import os
import requests
from core.loggers import *
from core.addon import *
from core.integrator import integrator

database_url = "https://raw.githubusercontent.com/strikersfran/repository.steelchannels/master/steelchannels.db"
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
R_PATH = os.path.join("addons",ADDON_ID)
F_PATH = os.path.join("userdata",os.path.join("addon_data",ADDON_ID))

PATH_DATA = os.path.join(ADDON.getAddonInfo("path").replace(R_PATH,"")[:-1],F_PATH)

if not os.path.exists(PATH_DATA):
    os.mkdir(PATH_DATA)

PATH_DB = os.path.join(PATH_DATA,"steelchannels.db")

def run():
    try:
        
        dialog = create_dialog("Actualizando base de datos")
        callback = progress_update(dialog)  

        database = requests.get(database_url)

        if database:
            if os.path.exists(PATH_DB):
                os.remove(PATH_DB)

            open(PATH_DB, 'wb').write(database.content)
        
        #verificamos si esta configurado para integrar con la base de datos de kodi
        if INTEGRATE and FOLDER !="":
            integrator(callback)

        dialog.close()

    except Exception as error:
        log("Error al ejecutar el servicio: "+str(error))
        if dialog:
            dialog.close()

if __name__ == '__main__':
    run()