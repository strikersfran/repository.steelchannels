ok: https://cinecalidad.ms/?trembed=8&trid=105741&trtype=1
streamlare: https://cinecalidad.ms/?trembed=10&trid=105741&trtype=1
fembed: https://cinecalidad.ms/?trembed=11&trid=105741&trtype=1

trembed: significa el id del servidor de streaming para esta pelicula, varia para cada pelicula (ok, streamlare, fembed)
trid: se refiere al id de la pelicula
trtype: tipo de contenido

podemos armar el url para el plugin de la siguiente manera
plugin://plugin.video.steelchannels.studio/?ok=8&streamlare=10&fembed=11&trid=105741&trtype=1

Podemos con estos datos contruir las url princiales de los embed y luego extraer en tiempo de jejecucion el url final

Podemos sacar un menu Para seleccionar los diferentes servidores


https://vanfem.com/api/source/k8qqda344emlmm4
