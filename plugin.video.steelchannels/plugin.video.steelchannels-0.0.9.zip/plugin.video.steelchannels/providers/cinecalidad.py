import requests
from bs4 import BeautifulSoup
from core.loggers import *
from core.addon import *
import urllib.parse
import servers.streamlare as streamlare
import servers.fembed as fembed
import servers.okru as okru
from core.database import *
from datetime import datetime, timedelta
#import pytz

import xbmcgui
import xbmcplugin

base_url = "https://cinecalidad.ms/"
fembed_api_url = "https://vanfem.com/api/source/"
streamlare_api_url = "https://sltube.org/api/video/stream/get?id="
okru_url = "https://ok.ru/videoembed/"

PATH_MOVIES = os.path.join(FOLDER, 'cinecalidad/movies')
PATH_SERIES = os.path.join(FOLDER, 'cinecalidad/series')
CREATED = 0
REMOVED = 0

headers = {
    'User-Agent': USERAGENT,
    "Referer": base_url
}


#para obtener el id finales de los servidores embed
def get_id_embed(url):
    try:
        if base_url not in url:
            url = base_url+"?"+url
        page = requests.get(url, timeout=30)
        soup = BeautifulSoup(page.content, "html.parser")

        iframe = soup.find("iframe")
        id = iframe["src"].split("/")[-1]       

        return id

    except requests.exceptions.Timeout:
        debug("Tiempo exedido en Cinecalidad get_embed")
        return False
    except requests.exceptions.RequestException as e:    
        debug("Cinecalidad get_embed Excepcion: " +str(e))
        return False

#para obtener el url final de fembed segun cinecalidad
def get_url_fembed(url):
    
    id = get_id_embed(url)

    if id:
        log("Fembed ID:" +id)

        url_final = fembed_api_url+id

        return url_final
    else:
        return False

#para obtener el url final de streamlare segun cinecalidad
def get_url_streamlare(url):
   
    id = get_id_embed(url)
    if id:
        log("Streamlare ID:" +id)

        url_final = streamlare_api_url+id+"&streamlare=true"

        return url_final    
    else:
        return False

#para obtener el url final de ok.ru segun cinecalidad
def get_url_okru(url):
   
    id = get_id_embed(url)
    if id:
        log("Ok.ru ID:" +id)

        url_final = okru_url+id

        return url_final    
    else:
        return False

#funcion para reproducir una video
def play(handle,url):
    #convertimos los parametros en array
    data= urllib.parse.parse_qs(url)
    debug("data url: "+str(data))
    
    #verificamos si tenemos mas de un servidor disponible
    server_num = 0
    list = []
    index = 0 #seleccion por defecto
    if data["ok"][0] != "0":
        server_num+=1
        list.append("Servidor Ok.ru")
    if data["streamlare"][0] != "0":
        server_num+=1
        list.append("Servidor Streamlare")
    if data["fembed"][0] != "0":
        server_num+=1
        list.append("Servidor Fembed (Preferido)")
    
    #abrimos una ventana de seleecion
    if server_num > 1:        
        index = xbmcgui.Dialog().contextmenu(list)                        
    
    if index >= 0:
        if "Ok" in list[index]:
            url_db = True
            debug("Seleccionado el servidor OK.ru")
            #verificamos si ya existe el url final en la base de datos
            row = get_movie_for_stream(data["trid"][0], "ok")
            debug("Row: "+str(row))
            if not (row is None):
                if row[4] != "" and row[4] != None and row[5] != "" and row[5] != None:
                    now = datetime.now()
                    timestamp = datetime.timestamp(now+timedelta(hours=4))
                    debug("fecha actual: "+str(now))
                    debug("timestamp actual: "+str(timestamp))
                    if int(row[5]) > int(timestamp):#significa que aun es valido el url
                        debug("existe un url valido, timestamp: "+str(row[5]))
                        xbmcplugin.setResolvedUrl(handle, True, listitem=create_list(row[4]))
                        return                
                if row[3] != "":
                    url = row[3]  
                    debug("Url de la base de datos") 
                else:
                    url_db = None
            if row is None or url_db is None:
                url = get_url_okru("trembed="+data["ok"][0]+"&trid="+data["trid"][0]+"&trtype="+data["trtype"][0])
                set_permanete_url_movie_stream(data["trid"][0], "ok",url)
            #xbmcplugin.setResolvedUrl(handle, True, listitem=okru.create_list(url,headers,data["trid"][0]))
            okru.create_list(url,headers,data["trid"][0],handle)

        elif "Streamlare" in list[index]:
            url_db = True
            debug("Seleccionado el servidor Streamlare")
            #verificamos si ya existe el url final en la base de datos
            row = get_movie_for_stream(data["trid"][0], "streamlare")
            debug("Row: "+str(row))
            if not (row is None):
                if row[4] != "" and row[4] != None and row[5] != "" and row[5] != None:
                    now = datetime.now()
                    timestamp = datetime.timestamp(now+timedelta(hours=4))
                    debug("fecha actual: "+str(now))
                    debug("timestamp actual: "+str(timestamp))
                    if int(row[5]) > int(timestamp):#significa que aun es valido el url
                        debug("existe un url valido, timestamp: "+str(row[5]))
                        xbmcplugin.setResolvedUrl(handle, True, listitem=create_list(row[4]))
                        return
                if row[3] != "":
                    url = row[3]  
                    debug("Url de la base de datos")             
                else:
                    url_db = None
            if row is None or url_db is None:
                url = get_url_streamlare("trembed="+data["streamlare"][0]+"&trid="+data["trid"][0]+"&trtype="+data["trtype"][0])
                set_permanete_url_movie_stream(data["trid"][0], "streamlare",url)
                
            xbmcplugin.setResolvedUrl(handle, True, listitem=streamlare.create_list(url,headers,data["trid"][0]))
        elif "Fembed" in list[index]:
            url_db = True
            debug("Seleccionado el servidor Fembed")
            row = get_movie_for_stream(data["trid"][0], "fembed")
            debug("Row: "+str(row))
            if not (row is None):
                if row[4] != "" and row[4] != None and row[5] != "" and row[5] != None:
                    now = datetime.now()
                    timestamp = datetime.timestamp(now+timedelta(hours=4))
                    debug("fecha actual: "+str(now))
                    debug("timestamp actual: "+str(timestamp))
                    if int(row[5]) > int(timestamp):#significa que aun es valido el url
                        debug("existe un url valido, timestamp: "+str(row[5]))
                        xbmcplugin.setResolvedUrl(handle, True, listitem=create_list(row[4]))
                        return
                if row[3] != "":
                    url = row[3]    
                    debug("Url de la base de datos")           
                else:
                    url_db = None
            if row is None or url_db is None:
                url = get_url_fembed("trembed="+data["fembed"][0]+"&trid="+data["trid"][0]+"&trtype="+data["trtype"][0])
                set_permanete_url_movie_stream(data["trid"][0], "fembed",url)
            xbmcplugin.setResolvedUrl(handle, True, listitem=fembed.create_list(url,headers,data["trid"][0]))

    else:
        showErrorNotification("No se pudo reproducir el contenido")

#funcion para reproducir una video
def play_serie(handle,episode_id):

    stream_ok = get_episodie_stream(episode_id,'ok')   
    stream_streamlare = get_episodie_stream(episode_id,'streamlare')
    stream_fembed = get_episodie_stream(episode_id,'fembed') 
    #verificamos si tenemos mas de un servidor disponible
    server_num = 0
    list = []
    index = 0 #seleccion por defecto
    if not (stream_ok is None):
        server_num+=1
        list.append("Servidor Ok.ru")
    if not (stream_streamlare is None):
        server_num+=1
        list.append("Servidor Streamlare")
    if not (stream_fembed is None):
        server_num+=1
        list.append("Servidor Fembed (Preferido)")
    
    #abrimos una ventana de seleecion
    if server_num > 1:        
        index = xbmcgui.Dialog().contextmenu(list)                        
    
    if index >= 0:
        if "Ok" in list[index]:
            url_db = True
            debug("Seleccionado el servidor OK.ru")            
            
            if stream_ok[4] != "" and stream_ok[4] != None and stream_ok[5] != "" and stream_ok[5] != None:
                now = datetime.now()
                timestamp = datetime.timestamp(now+timedelta(hours=4))
                debug("fecha actual: "+str(now))
                debug("timestamp actual: "+str(timestamp))
                if int(stream_ok[5]) > int(timestamp):#significa que aun es valido el url
                    debug("existe un url valido, timestamp: "+str(stream_ok[5]))
                    xbmcplugin.setResolvedUrl(handle, True, listitem=create_list(stream_ok[4]))
                    return                
            if stream_ok[3] != "":
                url = stream_ok[3]  
                debug("Url de la base de datos") 
            else:
                url_db = None
            
            okru.create_list(url,headers,episode_id,handle,type="episode")

        elif "Streamlare" in list[index]:
            url_db = True
            debug("Seleccionado el servidor Streamlare")
            
            if stream_streamlare[4] != "" and stream_streamlare[4] != None and stream_streamlare[5] != "" and stream_streamlare[5] != None:
                now = datetime.now()
                timestamp = datetime.timestamp(now+timedelta(hours=4))
                debug("fecha actual: "+str(now))
                debug("timestamp actual: "+str(timestamp))
                if int(stream_streamlare[5]) > int(timestamp):#significa que aun es valido el url
                    debug("existe un url valido, timestamp: "+str(stream_streamlare[5]))
                    xbmcplugin.setResolvedUrl(handle, True, listitem=create_list(stream_streamlare[4]))
                    return
            if stream_streamlare[3] != "":
                url = stream_streamlare[3]  
                debug("Url de la base de datos")             
            else:
                url_db = None            
                
            xbmcplugin.setResolvedUrl(handle, True, listitem=streamlare.create_list(url,headers,episode_id,type="episode"))
        elif "Fembed" in list[index]:
            url_db = True
            debug("Seleccionado el servidor Fembed")
            
            if stream_fembed[4] != "" and stream_fembed[4] != None and stream_fembed[5] != "" and stream_fembed[5] != None:
                now = datetime.now()
                timestamp = datetime.timestamp(now+timedelta(hours=4))
                debug("fecha actual: "+str(now))
                debug("timestamp actual: "+str(timestamp))
                if int(stream_fembed[5]) > int(timestamp):#significa que aun es valido el url
                    debug("existe un url valido, timestamp: "+str(stream_fembed[5]))
                    xbmcplugin.setResolvedUrl(handle, True, listitem=create_list(stream_fembed[4]))
                    return
            if stream_fembed[3] != "":
                url = stream_fembed[3]    
                debug("Url de la base de datos")           
            else:
                url_db = None
            
            xbmcplugin.setResolvedUrl(handle, True, listitem=fembed.create_list(url,headers,episode_id,type="episode"))

    else:
        showErrorNotification("No se pudo reproducir el contenido")

def create_list(file):    
    
    post = "|user-agent="+headers["User-Agent"]+"&referer="+headers["Referer"]
    list_item = xbmcgui.ListItem("", path=file+post)        
    list_item.setInfo(type='Video', infoLabels={'Title': "", 'plot': ""})

    if ".mp4" in file:
            list_item.setMimeType("video/mp4")
    elif ".m3u8" in file:
        list_item.setProperty('inputstream', 'inputstream.adaptive')
        list_item.setProperty('inputstream.adaptive.manifest_type', "hls")  
        #list_item.setProperty('inputstream.adaptive.stream_headers', 'user-agent='+USERAGENT)            
        list_item.setProperty('inputstream.adaptive.stream_selection_type', 'adaptive')
        list_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
        list_item.setProperty('inputstream.adaptive.chooser_resolution_max', QUALITY)

    return list_item

