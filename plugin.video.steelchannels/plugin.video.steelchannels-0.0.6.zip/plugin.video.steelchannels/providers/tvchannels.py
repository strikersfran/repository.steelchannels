import xbmcgui
import xbmcplugin
from core.database import *
from core.loggers import *
from servers.okru import create_list as youtube_list

#funcion para reproducir una canal
def play(handle,sources):
    
    list = []
    index = 0 #seleccion por defecto

    if len(sources) > 1:
        for i in range(len(sources)):
            list.append("Opción "+str(i+1))

        index = xbmcgui.Dialog().contextmenu(list)
        xbmcplugin.setResolvedUrl(handle, True, listitem=create_list(sources[index]))

    else:
        xbmcplugin.setResolvedUrl(handle, True, listitem=create_list(sources[0]))
        
def create_list(file):

    if ".mpd" in file:
        listitem = xbmcgui.ListItem(path=file)
        listitem.setMimeType('application/xml+dash')
        listitem.setContentLookup(False)
        listitem.setProperty('inputstream', 'inputstream.adaptive')
        listitem.setProperty('inputstream.adaptive.manifest_type', 'mpd')
        
        #para listas con licencia visitar: https://github.com/xbmc/inputstream.adaptive/wiki/Integration#inputstreamadaptivelicense_type
        
        return listitem

    if "youtube.com" in file:        
        file=youtube_list(file,None,None,None,"Youtube")

    elif "dailymotion.com" in file:        
        file=youtube_list(file,None,None,None,"Dailymotion")
    elif "twitch.tv" in file:        
        file=youtube_list(file,None,None,None,"TwitchStream")
        
    post = "|user-agent=ExoPlayer"
    list_item = xbmcgui.ListItem(path=file+post)        
    list_item.setInfo(type='video', infoLabels={'Title': "", 'plot': ""})
    
    if ".m3u8" in file:
        list_item.setProperty('inputstream', 'inputstream.adaptive')
        list_item.setProperty('inputstream.adaptive.manifest_type', "hls")  
        #list_item.setProperty('inputstream.adaptive.stream_headers', 'user-agent='+USERAGENT)            
        #list_item.setProperty('inputstream.adaptive.stream_selection_type', 'adaptive')       
        list_item.setContentLookup(False)
    else:
        list_item.setMimeType("video/mp4")

    return list_item
        

