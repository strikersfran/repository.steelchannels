from core.loggers import *
from core.database import get_movie_no_info, set_movie_info_art,set_movie_tmdb_id
from lib.tmdb3 import set_key, set_cache, set_locale, Collection, Movie, Person, Studio, TMDBRequestError
import json


set_key('e122a8356e1194b089089d7e49e09f62')
set_cache(engine='file', filename='tmdb3cache')
set_locale('es', 'es')

def tmdb_tool(callback,start=0,porc=100):
    movies = get_movie_no_info()    
    
    avance = start
    steep = int(porc / len(movies))

    for movie in movies: 
        avance = avance + steep
        callback(avance)               
        movieInfo, movieArt = tmdb_movie_info(movie[3],movie[0])
        #guardamos la informacion en la base de datos
        if movieInfo and movieArt:
            set_movie_info_art(movie[0],json.dumps(movieInfo),json.dumps(movieArt))        

    callback(porc)

#para estraer la información del api TMDB
def tmdb_movie_info(id,movie_id):
    try:
        m = Movie(id)
        geners = []
        countries = []
        studios = []
        casts = []
        poster = m.poster.geturl()

        for gener in m.genres:
            geners.append(gener.name)
        for country in m.countries:
            countries.append(country.name)
        for studio in m.studios:
            studios.append(studio.name)
        for cast in m.cast:
            casts.append(cast.name)

        movieInfo={
            'title':m.title,
            'originaltitle':m.originaltitle,
            'genre': geners,
            'country': countries,
            'year': "" if m.releasedate is None else m.releasedate.year,
            'plot': m.overview,
            'studio': studios,
            'mediatype': 'movie',
            'cast':casts
        }
        movieArt={
            'thumb': m.backdrop.geturl(), 
            'poster': poster,
            'icon': m.backdrop.geturl(), 
            'landscape':m.backdrop.geturl(),
            'clearart':m.backdrop.geturl(),
            'clearlogo':m.backdrop.geturl(),
            'fanart': m.backdrop.geturl()
        }

        return movieInfo, movieArt

    except Exception as e:        
        if str(e) == "34":#el tmdb_id no se encuentra registrado
            set_movie_tmdb_id(movie_id,0)
        return None, None