# -*- coding: utf-8 -*-

import xbmc

from core.addon import SERVICE_FREQUENCY

MONITOR = xbmc.Monitor()

if __name__ == '__main__':
    while not MONITOR.abortRequested():        
        
        if MONITOR.waitForAbort(SERVICE_FREQUENCY * 3600):
            break
