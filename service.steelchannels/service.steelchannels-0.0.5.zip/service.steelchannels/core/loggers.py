import xbmc
import xbmcaddon
import xbmcgui

from core.addon import ADDON_NAME, ADDON_VERSION

PG = 0

def debug(content):
    log(content, xbmc.LOGDEBUG)

def notice(content):
    log(content, xbmc.LOGINFO)

def log(msg, level=xbmc.LOGINFO):
    addon = xbmcaddon.Addon()
    addonID = addon.getAddonInfo('id')
    xbmc.log('%s: %s' % (addonID, msg), level)

def showInfoNotification(message):
    xbmcgui.Dialog().notification(ADDON_NAME, message, xbmcgui.NOTIFICATION_INFO, 5000)

def showErrorNotification(message):
    xbmcgui.Dialog().notification(ADDON_NAME, message,xbmcgui.NOTIFICATION_ERROR, 5000)

def progress_update(dialog):
    def inner(current):
        dialog.update(current)

    return inner

def progress_info(dialog):
    def inner(current, total, start=False, end=False):
        global PG
        dialog.update(PG + current)
        if current + 1 == total and end is True:
            PG += total

    return inner

def get_dialog_header():
    return '%s - %s' % (ADDON_NAME, ADDON_VERSION)

def create_dialog(message):
    dialog = xbmcgui.DialogProgressBG()
    dialog.create(get_dialog_header(), message)
    return dialog