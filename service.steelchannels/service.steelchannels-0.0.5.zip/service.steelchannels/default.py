import sys
from core.loggers import *
from providers.tvchannels import tvchannels

try:
    if len(sys.argv) > 1:
        param = sys.argv[1]
    else:
        param = "action=download"

    if param == "action=download_cinecalidad":
        log("Descargando el contenido de Cinecalidad")
    elif param == "action=download_tv":

        dialog = create_dialog("Descargando canales de TV")
        callback = progress_update(dialog)

        if not tvchannels(callback):
            showErrorNotification("Error al descargar los canales de TV")  
                      
        dialog.close()
    else:
        log("Descargando todo el contenido")
except Exception as error:
    log("Error al ejecutar el servicio: "+str(error))
    if dialog:
        dialog.close()