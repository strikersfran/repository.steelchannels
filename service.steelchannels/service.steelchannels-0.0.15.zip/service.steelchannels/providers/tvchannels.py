import requests
import json
from core.database import *
from core.loggers import *

#para descargar el cotenido de los canales de televisión
def tvchannels(callback,start=0,porc=100):

    channels_url = "https://raw.githubusercontent.com/strikersfran/repository.steelchannels/master/tvchannels.json"

    try:
        response = requests.get(channels_url, timeout=30)
        channels = response.json()

        avance = start
        steep = int(porc / len(channels))

        for channel in channels:
            #mostrar el avance
            avance = avance + steep
            callback(avance)

            channel["source"] = json.dumps(channel["source"])
            add_tv(channel)
            
        #en este paso se cumple el 100% del proceso
        callback(porc)

        return True

    except requests.exceptions.Timeout:
        debug("Tiempo exedido para acceder a la lista de canales")
        return False
    except requests.exceptions.RequestException as e:    
        debug("tvchannels Excepcion: " +str(e))
        return False
        

