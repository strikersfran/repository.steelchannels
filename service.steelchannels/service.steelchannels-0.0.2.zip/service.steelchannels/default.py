import sys
from core.loggers import *
from providers.tvchannels import tvchannels

try:
    param = sys.argv[1]
    if param == "action=download_cinecalidad":
        log("Descargando el contenido de Cinecalidad")
    elif param == "action=download_tv":

        dialog = create_dialog("Descargando canales de TV")
        callback = progress_update(dialog)

        if not tvchannels(callback):
            showErrorNotification("Error al descargar los canales de TV")  
                      
        dialog.close()
    else:
        log("Descargando todo el contenido")
except:
    log("Error al ejecutar el servicio")