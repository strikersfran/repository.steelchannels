import requests
import json
from core.database import *
from core.loggers import *

#para descargar el cotenido de los canales de televisión
def tvchannels(callback,porc=100):

    channels_url = "https://raw.githubusercontent.com/strikersfran/repository.steelchannels/master/tvchannels.json"

    try:
        response = requests.get(channels_url, timeout=30)
        channels = response.json()

        #este paso se cumple el 50% del proceso
        callback(porc//2)

        for channel in channels:
            channel["source"] = json.dumps(channel["source"])
            add_tv(channel)            
        #en este paso se cumple el 100% del proceso
        callback(porc)

        return True

    except requests.exceptions.Timeout:
        debug("Tiempo exedido para acceder a la lista de canales")
        return False
    except requests.exceptions.RequestException as e:    
        debug("tvchannels Excepcion: " +str(e))
        return False
        

