import sys
from core.loggers import *
from providers.tvchannels import tvchannels
from providers.cinecalidad import cinecalidad

try:
    if len(sys.argv) > 1:
        param = sys.argv[1]
    else:
        param = "action=download"

    if param == "action=download_cinecalidad":
        dialog = create_dialog("Descargando contenido de Cinecalidad")
        callback = progress_update(dialog)

        if not cinecalidad(callback):
            showErrorNotification("Error al descargar el contenido de Cinecalidad")
    elif param == "action=download_tv":

        dialog = create_dialog("Descargando canales de TV")
        callback = progress_update(dialog)

        if not tvchannels(callback):
            showErrorNotification("Error al descargar los canales de TV")
    else:
        dialog = create_dialog("Descargando Full Contenido")
        callback = progress_update(dialog)

        if not tvchannels(callback,25):
            showErrorNotification("Error al descargar los canales de TV") 

        if not cinecalidad(callback,75):
            showErrorNotification("Error al descargar el contenido de Cinecalidad")

    dialog.close()

except Exception as error:
    log("Error al ejecutar el servicio: "+str(error))
    if dialog:
        dialog.close()