import sys
from core.loggers import *

try:
    log("Descargando el contenido")
except:
    log("Error al ejecutar el servicio")