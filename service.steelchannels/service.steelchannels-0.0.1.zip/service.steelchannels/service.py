# -*- coding: utf-8 -*-

import xbmc

SERVICE_FREQUENCY = 1

MONITOR = xbmc.Monitor()

if __name__ == '__main__':
    while not MONITOR.abortRequested():        
        
        if MONITOR.waitForAbort(SERVICE_FREQUENCY * 3600):
            break
