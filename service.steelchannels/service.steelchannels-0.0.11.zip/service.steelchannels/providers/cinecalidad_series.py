import base64
import requests
from bs4 import BeautifulSoup
from core.loggers import *
from core.addon import *
from core.database import *

base_url = "https://cinecalidad.ms"
url_ajax = base_url+"/wp-admin/admin-ajax.php"
fembed_api_url = "https://vanfem.com/api/source/"
streamlare_api_url = "https://sltube.org/api/video/stream/get?id="
okru_url = "https://ok.ru/videoembed/"

PATH_SERIES = os.path.join(FOLDER, os.path.join('cinecalidad','series'))
CREATED = 0
REMOVED = 0

headers = {
    'User-Agent': USERAGENT,
    "Referer": base_url,

}

def cinecalidad_series(callback,start=0,porc=100):
    
    try:
        main_page = requests.get(base_url+"/serie", timeout=30)
        soup_main = BeautifulSoup(main_page.content, "html.parser")

        results_pages = soup_main.find_all('a',class_="page-numbers")

        #obtenemos el valor de la ultima pagina
        last_page_num = results_pages[-2].text.strip()
        if len(results_pages[-2]["href"].split("?"))>1:
            params = results_pages[-2]["href"].split("?")[1]
        else:
            params=""

        log("Ultima pagina de serie: "+str(last_page_num))
        
        avance = start
        #solo descargamos una solo pagina porque el proceso es muy largo
        #ultima pagina visitada
        if CINECALIDAD_SERIE_PAGE != '0':
            last_page_num = int(CINECALIDAD_SERIE_PAGE)-1#la ultima pagina descargada menos una o sea la siguiente
            if CINECALIDAD_SERIE_PAGE == '1':
                last_page_num = int(CINECALIDAD_SERIE_PAGE)
            
        log("Url page: "+base_url+"/serie/page/"+str(last_page_num)+"/?"+params)
        
        page = requests.get(base_url+"/serie/page/"+str(last_page_num)+"/?"+params, timeout=30, headers=headers)
        soup = BeautifulSoup(page.content, "html.parser")
        items = soup.find_all('a', class_="absolute")

        log("Descargando la pagina: "+str(last_page_num))                    
        
        steep = int(porc / len(items))
        for item in items:
            avance = avance + steep
            callback(avance)
            if item["href"]:
                log(item["href"])
                get_serie(item["href"])

        #para grabar que ya fue descargada la pagina
        set_setting('cinecalidad_serie_page',str(last_page_num))
            

        #integramos con la libreria de kodi
        # if FOLDER !='':            
        #     integrate_library()
        #     clean_update_library()
        
        callback(porc)       

        return True

    except requests.exceptions.Timeout:
        debug("Tiempo exedido para acceder al Servidor cinecalidad")
        return False
    except requests.exceptions.RequestException as e:    
        debug("Cinecalidad Excepcion: " +str(e))
        return False

def get_serie(url):
    try:
        page = requests.get(url, timeout=30)
        soup = BeautifulSoup(page.content, "html.parser")

        tmdb = soup.find("a",class_="tmdb-s")
        if tmdb:
            tmdb = tmdb["href"]
        #verificamos cuantas temporadas tiene
        seasons = soup.find(id="seasons").find_all("span",class_="title")
        
        if len(seasons) == 0:
            return False       
        #para estraer la imagen
        img = soup.find("main").find("article").find("figure").find("img", class_="lazyload")
        log(img["data-src"])

        trid=seasons[0]["data-serie"]
        trtype="1"#tipo de contenido      

        log("Serie encontrada: tmdb: " +str(tmdb))
        log("Temporadas: " +str(len(seasons)))
        log("Serie ID: "+trid)

        #creamos el registro en la base de datos
        serie = {"id":trid,"server":"cinecalidad","thumb":img["data-src"],"tmdb_id":tmdb.split("/")[-1],"name":img["alt"]}
        #guardamos los datos de la serie en la base de datos
        add_serie(serie)

        #buscamos los capitulos de las temporadas
        for season in seasons:
            try:
                form_data = {"action":"action_change_episode","season":season["data-season"],"serie":season["data-serie"]}
                response = requests.post(url_ajax, timeout=30,data=form_data,headers=headers)

                if response.status_code == 200:
                    #obtener la respuesta en json
                    response_json = response.json()

                    for data in response_json["d"]:
                        soup_image = BeautifulSoup(data["image"], "html.parser")
                        image = soup_image.find("img")
                        #log(image)
                        episodie={
                            #"id":data["id"], 
                            "serie_id":trid, 
                            "season_num": season["data-season"], 
                            "episodie_num": data["episode"],
                            "temp_id": data["id"],
                            "thumb": image["src"],
                            "name": "Temporada "+season["data-season"]+" Episodio "+data["episode"]
                        }
                        #agregamos el episodio a la base de datos
                        ep_id = add_episodie(episodie)

                        #extraemos los streams del episodio
                        streams = get_streams(data["url"],ep_id)
                        if streams:
                            add_episodie_stream(streams)
                
            except requests.exceptions.Timeout:
                debug("Tiempo exedido cinecalidad get_serie")
                return False
            except requests.exceptions.RequestException as e:    
                debug("Cinecalidad get_serie Excepcion: " +str(e))
                return False  

        return True

    except requests.exceptions.Timeout:
        debug("Tiempo exedido cinecalidad get_serie")
        return False
    except requests.exceptions.RequestException as e:    
        debug("Cinecalidad get_serie Excepcion: " +str(e))
        return False

def get_streams(url,e_id):

    try:
        page = requests.get(url, timeout=30)
        soup = BeautifulSoup(page.content, "html.parser")

        uls = soup.find("ul", class_="options")
        
        if uls:
            servers = uls.find_all("a",href="#!")
        else:
            return False
        
        fembed=None#servidor fembed
        streamlare=None#servidor streamlare
        ok=None#servidor ok.ru
        streams = []
        #vamos a buscar los url de los servidores ok, streamlare y fembed y extreaerle sus id
        #para tener las 3 opciones en la url de plugin player        
        for serv in servers:
            if serv.get("data-src") !='':
                url_temp = base64.b64decode(serv.get("data-src")).decode('utf-8')
                #https://streamlare.com/e/PjrQlo0OaY1nyOYk
                #remplazamos el url base del url_temp
                
                #LOS 3 MEJORES SERVIDORES
                if "FEMBED" in serv.get_text().upper():
                    fembed=fembed_api_url+url_temp.split("/")[-1]
                    streams.append({"episodie_id": e_id, "type":"fembed", "temp_id":0,"permanet_url": fembed,"estatus":1})
                if "STREAMLARE" in serv.get_text().upper():
                    streamlare=streamlare_api_url+url_temp.split("/")[-1]
                    streams.append({"episodie_id": e_id, "type":"streamlare", "temp_id":0,"permanet_url": streamlare,"estatus":1})
                if "OK" in serv.get_text().upper():
                    ok=okru_url+url_temp.split("/")[-1]
                    streams.append({"episodie_id": e_id, "type":"ok", "temp_id":0,"permanet_url": ok,"estatus":1})

        #si no existe ningunos de los servidores activo entonces no contruimos el url
        if ok is None and streamlare is None and fembed is None:
            log("Serie no tiene servidores online")
            return False
        else:
            return streams
        

    except requests.exceptions.Timeout:
        debug("Tiempo exedido cinecalidad get_movie")
        return False
    except requests.exceptions.RequestException as e:    
        debug("Cinecalidad get_movie Excepcion: " +str(e))
        return False