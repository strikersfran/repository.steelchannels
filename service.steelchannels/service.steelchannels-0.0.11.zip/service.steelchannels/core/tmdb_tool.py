from core.loggers import *
from core.database import get_movie_no_info,get_serie_no_info, set_movie_info_art,set_serie_info_art,set_movie_tmdb_id,set_serie_tmdb_id
from lib.tmdb3 import set_key, set_cache, set_locale, Series, Movie
import json


set_key('e122a8356e1194b089089d7e49e09f62')
set_cache(engine='file', filename='tmdb3cache')
set_locale('es', 'es')

def tmdb_tool(callback,start=0,porc=100):
    movies = get_movie_no_info()  
    series = get_serie_no_info() 
    
    avance = start
    if len(movies) > 0:
        steep = int((porc//2) / len(movies))

    for movie in movies: 
        avance = avance + steep
        callback(avance)               
        movieInfo, movieArt = tmdb_info(movie[3],movie[0],"movie")
        #guardamos la informacion en la base de datos
        if movieInfo and movieArt:
            set_movie_info_art(movie[0],json.dumps(movieInfo),json.dumps(movieArt))  

    if len(series) > 0:
        steep = int((porc//2) / len(series))

    for serie in series: 
        avance = avance + steep
        callback(avance)               
        serieInfo, serieArt = tmdb_info(serie[3],serie[0],"serie")
        #guardamos la informacion en la base de datos
        if serieInfo and serieArt:
            set_serie_info_art(serie[0],json.dumps(serieInfo),json.dumps(serieArt))

    callback(porc)

#para extraer la información de las peliculas y series
def tmdb_info(tmdb_id,db_id,type):
    try:        
        if type == "movie":
            m = Movie(tmdb_id)
        else:
            m = Series(tmdb_id)
        geners = []
        countries = []
        studios = []
        casts = []

        for gener in m.genres:
            geners.append(gener.name)
        if type == "movie":
            for country in m.countries:
                countries.append(country.name)
            for studio in m.studios:
                studios.append(studio.name)

            if m.releasedate is None:
                year = ""
            else:
                year = m.releasedate.year
        else:
            countries = m.origin_countries
            if m.first_air_date is None:
                year = ""
            else:
                year = m.first_air_date.year
            
        for cast in m.cast:
            casts.append(cast.name)        
        
        Info={
            'title':m.title if type == "movie" else m.name,
            'originaltitle':m.originaltitle if type == "movie" else m.original_name,
            'genre': geners,
            'country': countries,
            'year': year,
            'plot': m.overview,
            'studio': studios,
            'mediatype': type,
            'cast':casts
        }
        Art={
            'thumb': m.backdrop.geturl(), 
            'poster': m.poster.geturl(),
            'icon': m.backdrop.geturl(), 
            'landscape':m.backdrop.geturl(),
            'clearart':m.backdrop.geturl(),
            'clearlogo':m.backdrop.geturl(),
            'fanart': m.backdrop.geturl()
        }

        return Info, Art

    except Exception as e: 
        log(e)       
        if str(e) == "34":#el tmdb_id no se encuentra registrado
            if type == "movie":
                set_movie_tmdb_id(db_id,0)
            else:
                set_serie_tmdb_id(db_id,0)
        return None, None