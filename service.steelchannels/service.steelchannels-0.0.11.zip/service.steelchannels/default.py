import sys
from core.loggers import *
from providers.tvchannels import tvchannels
from providers.cinecalidad_movie import cinecalidad_movie
from providers.cinecalidad_series import cinecalidad_series
from core.tmdb_tool import tmdb_tool

def run():
    try:
        if len(sys.argv) > 1:
            param = sys.argv[1]
        else:
            param = "action=download"

        if param == "action=download_cinecalidad":
            dialog = create_dialog("Descargando contenido de Cinecalidad")
            callback = progress_update(dialog)

            if not cinecalidad_movie(callback,0,50):
                showErrorNotification("Error al descargar el contenido de Cinecalidad")

            if not cinecalidad_series(callback,50,25):
                showErrorNotification("Error al descargar las series de Cinecalidad")

            tmdb_tool(callback,75,25)

        elif param == "action=download_tv":

            dialog = create_dialog("Descargando canales de TV")
            callback = progress_update(dialog)

            if not tvchannels(callback,0,100):
                showErrorNotification("Error al descargar los canales de TV")
        else:
            dialog = create_dialog("Descargando Full Contenido")
            callback = progress_update(dialog)

            if not tvchannels(callback,0,25):
                showErrorNotification("Error al descargar los canales de TV") 

            if not cinecalidad_movie(callback,25,25):
                showErrorNotification("Error al descargar las películas de Cinecalidad")

            if not cinecalidad_series(callback,50,25):
                showErrorNotification("Error al descargar las series de Cinecalidad")

            tmdb_tool(callback,75,25)

        dialog.close()

    except Exception as error:
        log("Error al ejecutar el servicio: "+str(error))
        if dialog:
            dialog.close()

if __name__ == '__main__':
    run()
